create table voltage
(
volt varchar(200),
time varchar(200)
);

create table voltage2
(
volt2 varchar(200),
time2 varchar(200)
);

create table voltage3
(
volt3 varchar(200),
time3 varchar(200)
);
