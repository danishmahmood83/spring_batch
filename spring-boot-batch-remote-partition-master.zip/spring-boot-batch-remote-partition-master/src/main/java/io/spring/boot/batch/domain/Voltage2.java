package io.spring.boot.batch.domain;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class Voltage2 {

  
  
    private BigDecimal volt2;

 
    private double time2;

    public Voltage2() {
    }

    public Voltage2(final BigDecimal volt2, final double time2) {
        this.volt2 = volt2;
        this.time2 = time2;
    }

	public BigDecimal getVolt2() {
		return volt2;
	}

	public void setVolt2(BigDecimal volt2) {
		this.volt2 = volt2;
	}

	public double getTime2() {
		return time2;
	}

	public void setTime2(double time2) {
		this.time2 = time2;
	}

}
