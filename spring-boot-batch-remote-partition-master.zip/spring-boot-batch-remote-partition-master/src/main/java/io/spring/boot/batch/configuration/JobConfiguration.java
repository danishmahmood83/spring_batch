package io.spring.boot.batch.configuration;


import io.spring.boot.batch.domain.Voltage;
import io.spring.boot.batch.domain.Voltage2;
import io.spring.boot.batch.domain.Voltage3;
import io.spring.boot.batch.domain.VoltageFieldSetMapper;
import io.spring.boot.batch.domain.VoltageFieldSetMapper2;
import io.spring.boot.batch.domain.VoltageFieldSetMapper3;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.partition.PartitionHandler;
import org.springframework.batch.core.partition.support.MultiResourcePartitioner;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.integration.partition.BeanFactoryStepLocator;
import org.springframework.batch.integration.partition.MessageChannelPartitionHandler;
import org.springframework.batch.integration.partition.StepExecutionRequestHandler;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.support.MySqlPagingQueryProvider;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.core.MessagingTemplate;
import org.springframework.integration.scheduling.PollerMetadata;
import org.springframework.scheduling.support.PeriodicTrigger;

import javax.sql.DataSource;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableBatchProcessing
public class JobConfiguration implements ApplicationContextAware {

    private ApplicationContext applicationContext;
    private static final int GRID_SIZE = 4;

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Autowired
    public DataSource dataSource;

    @Autowired
    public JobExplorer jobExplorer;

    @Autowired
    public JobRepository jobRepository;
    
    @Value("${csv.file.path}")
	private String csvFilePath;
    
    @Value("${csv.file.path2}")
	private String csvFilePath2;
    
    
    @Value("${csv.file.path3}")
	private String csvFilePath3;


    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Bean
    public PartitionHandler partitionHandler(MessagingTemplate messagingTemplate) throws Exception {
        MessageChannelPartitionHandler partitionHandler = new MessageChannelPartitionHandler();

        partitionHandler.setStepName("slaveStep");
        partitionHandler.setGridSize(GRID_SIZE);
        partitionHandler.setMessagingOperations(messagingTemplate);
        partitionHandler.setPollInterval(5000l);
        partitionHandler.setJobExplorer(this.jobExplorer);
        partitionHandler.afterPropertiesSet();

        return partitionHandler;
    }
    
    @Bean
    public PartitionHandler partitionHandler2(MessagingTemplate messagingTemplate) throws Exception {
        MessageChannelPartitionHandler partitionHandler = new MessageChannelPartitionHandler();

        partitionHandler.setStepName("slaveStep2");
        partitionHandler.setGridSize(GRID_SIZE);
        partitionHandler.setMessagingOperations(messagingTemplate);
        partitionHandler.setPollInterval(5000l);
        partitionHandler.setJobExplorer(this.jobExplorer);
        partitionHandler.afterPropertiesSet();

        return partitionHandler;
    }
    
    @Bean
    public PartitionHandler partitionHandler3(MessagingTemplate messagingTemplate) throws Exception {
        MessageChannelPartitionHandler partitionHandler = new MessageChannelPartitionHandler();

        partitionHandler.setStepName("slaveStep3");
        partitionHandler.setGridSize(GRID_SIZE);
        partitionHandler.setMessagingOperations(messagingTemplate);
        partitionHandler.setPollInterval(5000l);
        partitionHandler.setJobExplorer(this.jobExplorer);
        partitionHandler.afterPropertiesSet();

        return partitionHandler;
    }

    @Bean
    public Partitioner partitioner() {
    	MultiResourcePartitioner partitioner = new	MultiResourcePartitioner(); 
    	PathMatchingResourcePatternResolver resolver = new	PathMatchingResourcePatternResolver(); 
		Resource[] resources = null;
		try {
			resources = resolver.getResources("file:///"+csvFilePath); }
		catch(IOException e) { 
			e.printStackTrace(); 
			} 
		partitioner.setResources(resources);
		partitioner.partition(GRID_SIZE); 
		return partitioner; 
    }
    

    @Bean
    public Partitioner partitioner2() {
    	MultiResourcePartitioner partitioner = new	MultiResourcePartitioner(); 
    	PathMatchingResourcePatternResolver resolver = new	PathMatchingResourcePatternResolver(); 
		Resource[] resources = null;
		try {
			resources = resolver.getResources("file:///"+csvFilePath2); }
		catch(IOException e) { 
			e.printStackTrace(); 
			} 
		partitioner.setResources(resources);
		partitioner.partition(GRID_SIZE); 
		return partitioner; 
    }

    @Bean
    public Partitioner partitioner3() {
    	MultiResourcePartitioner partitioner = new	MultiResourcePartitioner(); 
    	PathMatchingResourcePatternResolver resolver = new	PathMatchingResourcePatternResolver(); 
		Resource[] resources = null;
		try {
			resources = resolver.getResources("file:///"+csvFilePath3); }
		catch(IOException e) { 
			e.printStackTrace(); 
			} 
		partitioner.setResources(resources);
		partitioner.partition(GRID_SIZE); 
		return partitioner; 
    }


    @Bean
    @Profile("slave")
    @ServiceActivator(inputChannel = "inboundRequests", outputChannel = "outboundStaging")
    public StepExecutionRequestHandler stepExecutionRequestHandler() {
        StepExecutionRequestHandler stepExecutionRequestHandler = new StepExecutionRequestHandler();

        BeanFactoryStepLocator stepLocator = new BeanFactoryStepLocator();
        stepLocator.setBeanFactory(this.applicationContext);
        stepExecutionRequestHandler.setStepLocator(stepLocator);
        stepExecutionRequestHandler.setJobExplorer(this.jobExplorer);

        return stepExecutionRequestHandler;
    }

    @Bean(name = PollerMetadata.DEFAULT_POLLER)
    public PollerMetadata pollerMetadata() {
        PollerMetadata pollerMetadata = new PollerMetadata();
        pollerMetadata.setTrigger(new PeriodicTrigger(10));
        return pollerMetadata;
    }

    
    @Bean
	@StepScope
	@Qualifier("voltageItemReader") 
    public FlatFileItemReader<Voltage>	itemReader(@Value("#{stepExecutionContext['fileName']}") String filename) throws MalformedURLException 
    {
    	return new FlatFileItemReaderBuilder<Voltage>()
    			.name("voltItemReader")
    			.resource(new  UrlResource(filename))
    			.delimited() 
    			.names(new String[]{"volt","time"}).lineMapper(lineMapper()) 
    			.fieldSetMapper(new BeanWrapperFieldSetMapper<Voltage>() {{ setTargetType(Voltage.class);
    			}})
    			.build();
     }
    
    @Bean
  	@StepScope
  	@Qualifier("voltageItemReader2") 
      public FlatFileItemReader<Voltage2>	itemReader2(@Value("#{stepExecutionContext['fileName']}") String filename) throws MalformedURLException 
      {
      	return new FlatFileItemReaderBuilder<Voltage2>()
      			.name("voltItemReader2")
      			.resource(new  UrlResource(filename))
      			.delimited() 
      			.names(new String[]{"volt2","time2"}).lineMapper(lineMapper2()) 
      			.fieldSetMapper(new BeanWrapperFieldSetMapper<Voltage2>() {{ setTargetType(Voltage2.class);
      			}})
      			.build();
       }
    
    @Bean
  	@StepScope
  	@Qualifier("voltageItemReader3") 
      public FlatFileItemReader<Voltage3>	itemReader3(@Value("#{stepExecutionContext['fileName']}") String filename) throws MalformedURLException 
      {
      	return new FlatFileItemReaderBuilder<Voltage3>()
      			.name("voltItemReader3")
      			.resource(new  UrlResource(filename))
      			.delimited() 
      			.names(new String[]{"volt3","time3"}).lineMapper(lineMapper3()) 
      			.fieldSetMapper(new BeanWrapperFieldSetMapper<Voltage3>() {{ setTargetType(Voltage3.class);
      			}})
      			.build();
       }

    @Bean 
    public LineMapper<Voltage> lineMapper() {
    	final DefaultLineMapper<Voltage> defaultLineMapper = new DefaultLineMapper<>();
    	final DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer(); 
    	lineTokenizer.setDelimiter(";");
    	lineTokenizer.setStrict(false);
    	lineTokenizer.setNames(new String[]	{"volt","time"});
    	final VoltageFieldSetMapper fieldSetMapper = new VoltageFieldSetMapper();
    	defaultLineMapper.setLineTokenizer(lineTokenizer);
    	defaultLineMapper.setFieldSetMapper(fieldSetMapper);
			return defaultLineMapper; 
		
    }
    
    @Bean 
    public LineMapper<Voltage2> lineMapper2() {
    	final DefaultLineMapper<Voltage2> defaultLineMapper = new DefaultLineMapper<>();
    	final DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer(); 
    	lineTokenizer.setDelimiter(";");
    	lineTokenizer.setStrict(false);
    	lineTokenizer.setNames(new String[]	{"volt2","time2"});
    	final VoltageFieldSetMapper2 fieldSetMapper = new VoltageFieldSetMapper2();
    	defaultLineMapper.setLineTokenizer(lineTokenizer);
    	defaultLineMapper.setFieldSetMapper(fieldSetMapper);
			return defaultLineMapper; 
		
    }

    
    @Bean 
    public LineMapper<Voltage3> lineMapper3() {
    	final DefaultLineMapper<Voltage3> defaultLineMapper = new DefaultLineMapper<>();
    	final DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer(); 
    	lineTokenizer.setDelimiter(";");
    	lineTokenizer.setStrict(false);
    	lineTokenizer.setNames(new String[]	{"volt3","time3"});
    	final VoltageFieldSetMapper3 fieldSetMapper = new VoltageFieldSetMapper3();
    	defaultLineMapper.setLineTokenizer(lineTokenizer);
    	defaultLineMapper.setFieldSetMapper(fieldSetMapper);
			return defaultLineMapper; 
		
    }
    
    @Bean
    @StepScope
	public JdbcBatchItemWriter<Voltage> itemWriter() { 
		return new JdbcBatchItemWriterBuilder<Voltage>()
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
				.sql("INSERT INTO voltage (volt, time) VALUES (:volt, :time)")
				.dataSource(this.dataSource) 
				.build();
		}
    
    @Bean
    @StepScope
	public JdbcBatchItemWriter<Voltage2> itemWriter2() { 
		return new JdbcBatchItemWriterBuilder<Voltage2>()
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
				.sql("INSERT INTO voltage2 (volt2, time2) VALUES (:volt2, :time2)")
				.dataSource(this.dataSource) 
				.build();
		}

    @Bean
    @StepScope
	public JdbcBatchItemWriter<Voltage3> itemWriter3() { 
		return new JdbcBatchItemWriterBuilder<Voltage3>()
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
				.sql("INSERT INTO voltage3 (volt3, time3) VALUES (:volt3, :time3)")
				.dataSource(this.dataSource) 
				.build();
		}

    @Bean
    public Step step1() throws Exception {
        return stepBuilderFactory.get("step1")
                .partitioner(slaveStep().getName(), partitioner())
                .step(slaveStep())
                .partitionHandler(partitionHandler(null))
                .build();
    }
    
    @Bean
    public Step step2() throws Exception {
        return stepBuilderFactory.get("step2")
                .partitioner(slaveStep2().getName(), partitioner2())
                .step(slaveStep2())
                .partitionHandler(partitionHandler2(null))
                .build();
    }
    
    @Bean
    public Step step3() throws Exception {
        return stepBuilderFactory.get("step3")
                .partitioner(slaveStep3().getName(), partitioner3())
                .step(slaveStep3())
                .partitionHandler(partitionHandler3(null))
                .build();
    }


    @Bean
    public Step slaveStep() throws MalformedURLException {
        return stepBuilderFactory.get("slaveStep")
                .<Voltage, Voltage>chunk(1000)
                .reader(itemReader(null))
                .writer(itemWriter())
                .build();
    }
    
    
    @Bean
    public Step slaveStep2() throws MalformedURLException {
        return stepBuilderFactory.get("slaveStep2")
                .<Voltage2, Voltage2>chunk(1000)
                .reader(itemReader2(null))
                .writer(itemWriter2())
                .build();
    }

    @Bean
    public Step slaveStep3() throws MalformedURLException {
        return stepBuilderFactory.get("slaveStep3")
                .<Voltage3, Voltage3>chunk(1000)
                .reader(itemReader3(null))
                .writer(itemWriter3	())
                .build();
    }

    @Bean(name="cvaJob")
    @Profile("master")
    public Job job() throws Exception {
        return jobBuilderFactory.get("job")
                .start(step1())
                .next(step2())
                .next(step3())
                .build();
    }
}
