package io.spring.boot.batch.domain;


import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Component;

@Component
public class VoltageFieldSetMapper3 implements FieldSetMapper<Voltage3> {

    @Override
    public Voltage3 mapFieldSet(FieldSet fieldSet) {
        final Voltage3 voltage3 = new Voltage3();

        voltage3.setVolt3(fieldSet.readBigDecimal("volt3"));
        voltage3.setTime3(fieldSet.readDouble("time3"));
        return voltage3;

    }

}
