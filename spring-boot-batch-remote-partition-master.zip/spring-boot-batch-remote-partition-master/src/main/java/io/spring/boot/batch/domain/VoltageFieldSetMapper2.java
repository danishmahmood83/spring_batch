package io.spring.boot.batch.domain;


import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Component;

@Component
public class VoltageFieldSetMapper2 implements FieldSetMapper<Voltage2> {

    @Override
    public Voltage2 mapFieldSet(FieldSet fieldSet) {
        final Voltage2 voltage2 = new Voltage2();

        voltage2.setVolt2(fieldSet.readBigDecimal("volt2"));
        voltage2.setTime2(fieldSet.readDouble("time2"));
        return voltage2;

    }

}
