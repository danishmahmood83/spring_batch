package io.spring.boot.batch.domain;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class Voltage3 {

  
  
    private BigDecimal volt3;

 
    private double time3;

    public Voltage3() {
    }

    public Voltage3(final BigDecimal volt3, final double time3) {
        this.volt3 = volt3;
        this.time3 = time3;
    }

	public BigDecimal getVolt3() {
		return volt3;
	}

	public void setVolt3(BigDecimal volt3) {
		this.volt3 = volt3;
	}

	public double getTime3() {
		return time3;
	}

	public void setTime3(double time3) {
		this.time3 = time3;
	}


}
