# spring-boot-batch-remote-partition

This is a initial attempt to create a simple Spring Boot Batch application using remote partitioning. The project is based on [LearningSpringBatch](https://github.com/mminella/LearningSpringBatch/tree/master/src/remotePartitioning).

## Prerequisite
Install RabbitMQ and MySQL in order to run properly.

Create a database table call `springbatch` in MySQL.